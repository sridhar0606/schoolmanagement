import React from 'react';
import { useState,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import api from '../api/index.js'
import axios from "axios";

function Staffs() {
  const navigate = useNavigate();

  const [staffname, setStaffname] = useState("");
  const [staffemail, setStaffemail] = useState("");
  const [staffnumber, setStaffnumber] = useState("");
  const [staffdob, setStaffdob] = useState("");
  const [successmsg, setSuccessmsg] = useState(false);
  const [phoneerror, setPhoneerror] = useState(false);
  const [arraylist, setArraylist] = useState([]);

   const [use , setUse] = useState("");
   const [id , setId] = useState("");

useEffect(() => {

 getstaff();

  },[]);



const  getstaff =()=>{
   api.StaffCollection().then (res => {
     setArraylist(res.data.data)
     })
   }

const remove =()=>{
  setStaffname("")
  setStaffemail("")
  setStaffnumber("")
  setStaffdob("")
}


const view =(name,email,mobile,dob,id,use)=>{
  setStaffname(name)
  setStaffemail(email)
  setStaffnumber(mobile)
  setStaffdob(dob)
  setUse(use)
  setId(id)
}

const deletestaff =(id)=>{
  alert(id)

 axios.delete(
    `http://localhost:5000/api/Removestaff/${id}`
  ).then((res) => {

  if(res.status == 200){
        getstaff();
      }

    })
}





  const handleChange = (e, obj) => {
    if (obj === "staffname") {
      setStaffname(e.target.value);
    } else if (obj === "staffemail") {
      setStaffemail(e.target.value);
    } else if (obj === "phonenumber") {
      if (e.target.value.length < 10 || e.target.value.length > 10) {
        setPhoneerror(true);
        setStaffnumber(e.target.value);
      } else {
        setPhoneerror(false);
        setStaffnumber(e.target.value);
      }
    } else {
      setStaffdob(e.target.value);
    }
  };
  const HandleSubmit = (e) => {
    e.preventDefault();

   


    if(use === "update"){

  const record ={
         id:id,
        name:staffname,
        email: staffemail,
        mobile:staffnumber,
        dob:staffdob
    }

      api.Staffupdate(record).then (res => {
       if(res.status == 200){

       alert(res.data.message)
        remove();
        getstaff();
       } else{

        alert(res.data.message)
       }
  
     })

    }else{

       const record ={
        name:staffname,
        email: staffemail,
        mobile:staffnumber,
        dob:staffdob
    }

    api.Createstaff(record).then (res => {


       if(res.status == 200){
        alert(res.data.message)
        remove();
        getstaff();
       } else{

        alert(res.data.message)
       }
      
  
     })

    }

 
   
  };
  const handlePageChange = () => {
    navigate("/");
  };
  return (
    <div class="Home">
      {console.log("nnnnn", arraylist)}
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2 class="home-head">Staffs Registration</h2>
            <button
              type="submit"
              class="convertbtn"
              style={{ float: "right" }}
              onClick={() => handlePageChange()}
            >
              Back
            </button>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8" style={{ display: "block", margin: "0 auto" }}>
            <form
              class="login100-form validate-form text-left"
              onSubmit={(e) => HandleSubmit(e)}
            >
              {successmsg === true ? (
                <>
                  <div class="successmsg">
                    <p>You are successfully registered as a staffs</p>
                  </div>
                </>
              ) : (
                ""
              )}


                    {use === "update" ? (
                <>
                 
              <center> <p>update staffs</p></center>
                 
                </>
              ) : (
                ""
              )}


              <div class="form-group">
                <label class="lable-name">
                  <b>Staff Name:</b>
                </label>
                <input
                  type="text"
                  class="form-control animate-focus"
                  id="name"
                  value={staffname}
                  placeholder="Enter your name"
                  autocomplete="off"
                  onChange={(e) => handleChange(e, "staffname")}
                  required
                />
              </div>
              <div class="form-group">
                <label class="lable-name">
                  <b>Email:</b>
                </label>
                <input
                  type="email"
                  class="form-control animate-focus"
                  id="email"
                  value={staffemail}
                  placeholder="Enter Your Email"
                  autocomplete="off"
                  onChange={(e) => handleChange(e, "staffemail")}
                  required
                />
              </div>
              <div class="form-group">
                <label class="lable-name">
                  <b>Phone Number:</b>
                </label>
                <input
                  type="text"
                  class="form-control animate-focus"
                  id="phonenumber"
                  value={staffnumber}
                  placeholder="Enter Your Phoneneumber"
                  autocomplete="off"
                  onChange={(e) => handleChange(e, "phonenumber")}
                  required
                />
                {phoneerror === true ? (
                  <>
                    <p style={{ color: "red" }}>*Phonenumber error</p>
                  </>
                ) : (
                  ""
                )}
              </div>
              <div class="form-group">
                <label class="lable-name">
                  <b>DOB:</b>
                </label>
                <input
                  type="date"
                  class="form-control animate-focus"
                  id="dob"
                  value={staffdob}
                  placeholder="Enter Your Email"
                  autocomplete="off"
                  onChange={(e) => handleChange(e, "staffdob")}
                  required
                />
              </div>
              <div>
                <button type="submit" class="convertbtn">
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <br />



        <h4 class="home-head">Staffs Record</h4>
      <div class="row">
        <div class="col-md-8" style={{ display: "block", margin: "0 auto" }}>
          <div class="table-responsive">
            <table class="table table-bordered" style={{ color: "#fff" }}>
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Phone Number</th>
                  <th scope="col">DOB</th>
                    <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {arraylist.map((list, index) => {
                  return (
                    <>
                      <tr key={index}>
                        <td>{list.Name}</td>
                        <td>{list.Email}</td>
                        <td>{list.Mobile}</td>
                        <td>{list.Dob}</td>
                        <td>
<div class="btn-group" role="group" aria-label="Basic example">
  <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#exampleModalCenter"  onClick={()=>view(list.Name,list.Email,list.Mobile,list.Dob,list._id)}><i class="far fa-eye"></i></button>
  <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#exampleModalCenter1" onClick={()=>view(list.Name,list.Email,list.Mobile,list.Dob,list._id,"update")}><i class="fas fa-edit"></i></button>
  <button type="button" class="btn btn-secondary"><i class="fas fa-trash-alt" onClick={()=>deletestaff(list._id)}></i></button>
</div> </td>
                      </tr>
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>



<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">View Cource</h5>
        <button type="button" class="close" data-dismiss="modal"  aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <p> <b>Staff Name:{staffname} </b> </p>
          <p> <b>Email:{staffemail} </b> </p>
          <p> <b>Mobile:{staffnumber} </b> </p>
          <p> <b>Dob:{staffdob} </b> </p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
       </div>

    </div>
  </div>
</div>



    </div>
  );
}

export default (Staffs);
