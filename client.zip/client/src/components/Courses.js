import React from 'react';
import { useState,useEffect  } from "react";
import { useNavigate } from "react-router-dom";
import api from '../api/index.js'
import { Form } from 'react-bootstrap';
import axios from "axios";

function Courses() {
  const navigate = useNavigate();


  const [course, setCourse] = useState("");
  const [staff, setStaff] = useState([]);
  const [User, setUser] = useState([1,2,3,4,5]);

  const [successmsg, setSuccessmsg] = useState(false);
  const [arraylist, setArraylist] = useState([]);
 const [selectedstaff, setSelectedstaff] = useState([]);
 const [id, setId] = useState([]);


 const getcource =()=>{
   api.CourseCollection().then (res => {
     // alert(JSON.stringify(res))
    setArraylist(res.data.data)
     })
 }


useEffect(() => {

  api.StaffCollection().then (res => {
    //  alert(JSON.stringify(res))
    setStaff(res.data.data)
     })
   getcource();

  },[]);



  const handleChange = (e, obj) => {

   if(obj == "course"){
    setCourse(e.target.value);
   }else if(obj == "multi"){
   setSelectedstaff([].slice.call(e.target.selectedOptions).map(item => item.value))
    } 
  };


  const HandleSubmit = (e) => {
    e.preventDefault();
    const record ={
       coursname:course,
       staff:selectedstaff
      }

 api.Createcource(record).then (res => {
       alert(JSON.stringify(res))
      if (res.data.staus == 200 ){

         alert("successfully")
      }

        })
      

  };


  const handlePageChange = () => {
    navigate("/");
  };

const viewcource=(name,staff,id)=>{
setCourse(name)
setUser(staff)
setId(id)

}

const deletecource=(id)=>{
 
 axios.delete(
    `http://localhost:5000/api/RemoveCourse/${id}`
  ).then((res) => {


    if(res.status == 200){

        getcource(); 
    }

  })

  
}



const HandleSubmitupdate=(e)=>{
  alert("s")
  e.preventDefault();
 const record ={
       id:id,
       coursname:course,
       staff:selectedstaff
      }

 api.updatacource(record).then (res => {
      
      if (res.data.staus == 200 ){

         alert("update successfully")
          getcource();

      }

        })
}

  return (
    <div class="Home">

      {console.log("sdds",arraylist

        )}

      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2 class="home-head">Course Registration</h2>
            <button
              type="submit"
              class="convertbtn"
              style={{ float: "right" }}
              onClick={() => handlePageChange()}
            >
              Back
            </button>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8" style={{ display: "block", margin: "0 auto" }}>
            <form
              class="login100-form validate-form text-left"
              onSubmit={(e) => HandleSubmit(e)}
            >
              {successmsg === true ? (
                <>
                  <div class="successmsg">
                    <p>You are successfully registered as a staffs</p>
                  </div>
                </>
              ) : (
                ""
              )}
              <div class="form-group">
                <label class="lable-name">
                  <b>Course Name:</b>
                </label>
                <input
                  type="text"
                  class="form-control animate-focus"
                  id="name"
                  value={course}
                  placeholder="Enter course"
                  autocomplete="off"
                  onChange={(e) => handleChange(e, "course")}
                  required
                />
              </div>
              <div class="form-group">
                <label class="lable-name">
                  <b>Staff Name :</b>
                </label>

            
      <Form.Control as="select" multiple value={selectedstaff}
      onChange={(e) => handleChange(e,"multi")}>

        {staff.map((list, index) => {
                  return (
       <option value={list.Name}>{list.Name}</option>
                  )})}

        </Form.Control>

              </div>
              <div>
                <button type="submit" class="convertbtn">
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <br />


        <h4 class="home-head">Cource Record</h4>
      <div class="row">
        <div class="col-md-8" style={{ display: "block", margin: "0 auto" }}>
          <div class="table-responsive">
            <table class="table table-bordered" style={{ color: "#fff" }}>
              <thead>
                <tr>
                  <th scope="col">Course Name</th>
                  <th scope="col">Staff Name</th>
                    <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {arraylist.map((list, index) => {
                  return (
                    <>
                      <tr key={index}>
                        <td>{list.CourseName}</td>
                        <td>
                          {list.StaffName.map((list1, index1) => {
                            return <>{list1} , </>;
                          })}
                        </td>
                        <td>
                        <div class="btn-group" role="group" aria-label="Basic example">
  <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#exampleModalCenter"  onClick={()=>viewcource(list.CourseName,list.StaffName,list._id)}><i class="far fa-eye"></i></button>
  <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#exampleModalCenter1" onClick={()=>viewcource(list.CourseName,list.StaffName,list._id)}><i class="fas fa-edit"></i></button>
  <button type="button" class="btn btn-secondary"><i class="fas fa-trash-alt" onClick={()=>deletecource(list._id)}></i></button>
</div>
                        </td>
                      </tr>
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>


<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">View Cource</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p> <b>Cource Name:{course} </b> </p>
          <p> <b>Staff Names </b> </p>
   
        {User.map((val,ind)=>(
           <> {ind+1}.{val} </>
          ))}


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
       </div>

    </div>
  </div>
</div>





<div class="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Update Cource</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    
        <form
              class="login100-form validate-form text-left"
              onSubmit={(e) => HandleSubmitupdate(e)}
            >
              {successmsg === true ? (
                <>
                  <div class="successmsg">
                    <p>You are successfully registered as a staffs</p>
                  </div>
                </>
              ) : (
                ""
              )}
              <div class="form-group">
                <label class="lable-name">
                  <b>Course Name:</b>
                </label>
                <input
                  type="text"
                  class="form-control animate-focus"
                  id="name"
                  value={course}
                  placeholder="Enter course"
                  autocomplete="off"
                  onChange={(e) => handleChange(e, "course")}
                  required
                />
              </div>
              <div class="form-group">
                <label class="lable-name">
                  <b>Staff Name :</b>
                </label>

            
      <Form.Control as="select" multiple value={selectedstaff}
      onChange={(e) => handleChange(e,"multi")}>

        {User.map((list, index) => {
                  return (
       <option value={list}>{list}</option>
                  )})}

        </Form.Control>

              </div>
              <div>
               <button type="submit" class="btn btn-success" >Submit</button>
              </div>
            </form>

   

      </div>
   
       
    </div>
  </div>
</div>


    </div>
  );
}

export default (Courses);
