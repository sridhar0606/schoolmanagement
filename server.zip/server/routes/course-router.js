const express = require('express')

const courseCtrl = require('../controllers/course-ctrl')

const router = express.Router()

router.post('/Createcource',courseCtrl.Createcource)

router.get('/CourseCollection',courseCtrl.CourseCollection)

router.delete('/RemoveCourse/:id',courseCtrl.RemoveCourse)

router.post('/updatacource',courseCtrl.updatacource)

module.exports = router