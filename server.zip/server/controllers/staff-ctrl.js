const Staff = require('../models/staff_model.js')

Createstaff = (req, res) => {
    const body = req.body
    console.log(body)

    if (!body) {
        return res.status(400).json({
            success: false,
            error: 'You must provide a movie',
        })
    }

var collection = {
                  Name: body.name,
                  Email: body.email,
                  Mobile:body.mobile,
                  Dob:body.dob
            }
    const staff = new Staff(collection)

    if (!staff) {
        return res.status(400).json({ success: false, error: err })
    }

    staff
        .save()
        .then(() => {
            return res.status(200).json({ visible:"true",color:"success",message:"Registration success " })
          })
        .catch(error => {
            return res.status(400).json({
                error,
                message: 'Registration un success!',
            })
        })
}

StaffCollection = async (req, res) => {

Staff.aggregate([{
  $group: { "_id": "$_id","Name":{ "$first": "$Name"},"Email":{ "$first": "$Email"},"Dob":{ "$first": "$Dob"},"Mobile":{ "$first": "$Mobile"}} 
      }
     ],(err,data )=> {

       

      if (data.length == 0) {
          return res.status(400).json({ success: false, error: err,message:"staff not found" })
        }
          else{
       return res.status(200).json({"data":data}) 
            }
        })

}


Staffupdate = async (req, res) => {

      console.log(req.body)

Staff.findOne({ _id:req.body.id}, (err, user) => {
     
     if (err) {
                return res.status(400).json({
                err,
                message: 'update not found!',
            })
           }
        

  Staff.updateOne({_id:req.body.id},
             {$set:{

                  Name: req.body.name,
                  Email: req.body.email,
                  Mobile: req.body.mobile,
                  Dob: req.body.dob

             }},(chg, update) => {


           if (chg) {
               return res.status(400).json({chg, message: 'update not successful'})
                }
    else{
          return res.status(200).json({chg, message: 'update successful'})
    }


  })
})

}

Removestaff = async (req, res) => {
console.log("ds",req.params.id)
 

  Staff.findOne({ _id:req.params.id }, (err, user) => {
      
     if (err) {
            return res.status(404).json({
                err,
                message: 'profile not found!',
            })
           }
  Staff.deleteOne({_id:req.params.id},(chg, remove) => {
       
           if (chg) {
               return res.status(404).json({chg, message: 'profile delete not successful'})
           }

else{
  
  return res.status(200).json({chg, message: 'profile delete  successful'})
        
     }
})

})

}


module.exports = {
    Createstaff,
    StaffCollection,
    Staffupdate,
    Removestaff
}